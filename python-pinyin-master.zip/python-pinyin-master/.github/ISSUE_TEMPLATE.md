## 运行环境

* 操作系统（Linux/macOS/Windows）：
* Python 版本：
* pypinyin 版本：


<!--
P.S. 可以通过 `python -V` 获取 Python 版本。
P.S. 可以通过 `pypinyin -V` 或者 `pip freeze |grep pypinyin` 或 `pypinyin.__version__` 获取 pypinyin 版本信息。
-->

## 问题描述


## 问题复现步骤


<!--
感谢反馈！❤️
-->
