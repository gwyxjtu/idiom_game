.. _contrib:

contrib
========


V2UMixin
---------

.. autoclass:: pypinyin.contrib.uv.V2UMixin


NeutralToneWith5Mixin
-----------------------

.. autoclass:: pypinyin.contrib.neutral_tone.NeutralToneWith5Mixin
